local TeleportModule = {}

function TeleportModule.Init(Tab)
    local Players = game:GetService("Players")
    local LocalPlayer = Players.LocalPlayer

    local VehiclePresets = {
        ["Pickup1_Vehicle"] = {
            Size = Vector3.new(10, 6, 18),
            Offset = CFrame.new(0, 3, 11.5)
        },
        ["UtilityTruck_Vehicle"] = {
            Size = Vector3.new(7, 3, 10),
            Offset = CFrame.new(0, 1.75, 5.75)
        },
        ["UtilityTruck2_Vehicle"] = {
            Size = Vector3.new(8, 3, 11),
            Offset = CFrame.new(0, 1.75, 6)
        },
    }

    local selectedTarget = nil
    local localTag = LocalPlayer.DisplayName .. " (You)"
    
    local tpBtn 

    local function GetPlayerList()
        local list = { localTag }
        for _, p in pairs(Players:GetPlayers()) do
            if p ~= LocalPlayer then
                table.insert(list, p.DisplayName)
            end
        end
        return list
    end

    local function GetVehicleSpecs(vehicleModel)
        if not vehicleModel then return nil end
        
        local itemNameObj = vehicleModel:FindFirstChild("ItemName")
        if itemNameObj and itemNameObj:IsA("StringValue") then
            return VehiclePresets[itemNameObj.Value]
        end
        return nil
    end

    local function Teleport(Pos)
        local Character = LocalPlayer.Character
        if not Character then return end
        
        local Humanoid = Character:FindFirstChildOfClass("Humanoid")
        local HumanoidRootPart = Character:FindFirstChild("HumanoidRootPart")
        if not HumanoidRootPart then return end

        local targetCFrame = CFrame.new(Pos + Vector3.new(0, 1, 0))

        local seatPart = Humanoid and Humanoid.SeatPart
        local vehicleModel = seatPart and seatPart:FindFirstAncestorOfClass("Model")

        if vehicleModel then
            local vehicleParts = {}
            for _, descendant in ipairs(vehicleModel:GetDescendants()) do
                if descendant:IsA("BasePart") then
                    vehicleParts[descendant] = descendant.Anchored
                    descendant.Anchored = true
                end
            end

            local preset = GetVehicleSpecs(vehicleModel)
            
            if preset then
                local detectionSize = preset.Size
                local detectionOffset = preset.Offset
                
                local currentPivot = vehicleModel:GetPivot()
                local movementTransform = targetCFrame * currentPivot:Inverse()
                
                local detectionCFrame = currentPivot * detectionOffset
                local overlapParams = OverlapParams.new()
                overlapParams.FilterType = Enum.RaycastFilterType.Exclude
                overlapParams.FilterDescendantsInstances = {vehicleModel, Character}
                overlapParams.RespectCanCollide = false
                
                local looseItems = workspace:GetPartBoundsInBox(detectionCFrame, detectionSize, overlapParams)
                local processedItems = {}
                
                for _, part in ipairs(looseItems) do
                    if part:IsA("BasePart") and not part.Anchored then
                        local rootModel = part:FindFirstAncestorOfClass("Model")
                        if rootModel and rootModel ~= workspace then
                            if not processedItems[rootModel] then
                                processedItems[rootModel] = true
                                rootModel:PivotTo(movementTransform * rootModel:GetPivot())
                            end
                        else
                            if not processedItems[part] then
                                processedItems[part] = true
                                part.CFrame = movementTransform * part.CFrame
                            end
                        end
                    end
                end
            end
            
            vehicleModel:PivotTo(targetCFrame)
            
            task.wait(0.05)
            for part, originalAnchorState in pairs(vehicleParts) do
                if part and part.Parent then
                    part.Anchored = originalAnchorState
                end
            end
        else
            HumanoidRootPart.CFrame = targetCFrame
        end
    end

    local storeData = {
        ["Wood R Us"]          = Vector3.new(265, 3, 57),
        ["Land Store"]         = Vector3.new(257, 3, -99),
        ["Boxed Cars"]         = Vector3.new(510, 3, -1465),
        ["Fancy Furnishings"]  = Vector3.new(500, 3, -1720),
        ["Links Logic"]        = Vector3.new(4607, 7, -795),
        ["Fine Arts Shop"]     = Vector3.new(5207, -166, 719),
        ["Bob's Shack"]        = Vector3.new(260, 8.4, -2542.0),
    }

    local regionData = {
        ["Cherry Meadow"]      = Vector3.new(220.9, 59.8, 1305.8),
        ["Volcano"]            = Vector3.new(-1585, 622, 1140),
        ["Swamp"]              = Vector3.new(-1209, 132, -801),
        ["Tiaga Peak"]         = Vector3.new(1448, 413, 3186),
        ["Snow Biome"]         = Vector3.new(890.0, 59.8, 1195.6),
        ["SnowGlow Biome"]     = Vector3.new(-1087.3, -5.9, -946.2),
        ["Cave"]               = Vector3.new(3581.0, -179.5, 430.0),
        ["Palm Island 1"]      = Vector3.new(2000, -6, -1500),
        ["Lonecave"]           = Vector3.new(115, -214, -1095),
    }

    local otherData = {
        ["Bridge"]             = Vector3.new(112.3, 11.0, -782.4),
        ["Docks"]              = Vector3.new(1114.0, -1.2, -197.0),
        ["The Den"]            = Vector3.new(323.0, 41.8, 1930.0),
        ["Safari"]             = Vector3.new(111.9, 11.0, -998.8),
        ["The Cabin"]          = Vector3.new(1244.0, 63.6, 2306.0),
        ["Bird Cave"]          = Vector3.new(4813.1, 17.7, -978.8),
        ["Strange Man"]        = Vector3.new(1061.0, 16.8, 1131.0),
        ["Green Box"]          = Vector3.new(-1668.1, 349.6, 1475.4),
        ["Light House"]        = Vector3.new(1464.8, 355.2, 3257.2),
        ["Shrine of Sight"]    = Vector3.new(-1600.0, 195.4, 919.0),
        ["Fridge"]             = Vector3.new(550.17,-1, -1714.16),
    }

    local function GetSortedKeys(DataTable)
        local keys = {}
        for k in pairs(DataTable) do table.insert(keys, k) end
        table.sort(keys)
        return keys
    end

    Tab:CreateSection("World Teleports")

    Tab:CreateDropdown("Stores", GetSortedKeys(storeData), "Select Store...", function(val)
        Teleport(storeData[val])
    end)

    Tab:CreateDropdown("Tree Regions", GetSortedKeys(regionData), "Select Region...", function(val)
        Teleport(regionData[val])
    end)

    Tab:CreateDropdown("Other POIs", GetSortedKeys(otherData), "Select Location...", function(val)
        Teleport(otherData[val])
    end)

    Tab:CreateSection("Player & Plot")
    
    local playerDropdown = Tab:CreateDropdown("Select Player", GetPlayerList(), "Select...", function(val)
        if val == localTag then
            selectedTarget = LocalPlayer.DisplayName
            if tpBtn then tpBtn:SetDisabled(true) end
        else
            selectedTarget = val
            if tpBtn then tpBtn:SetDisabled(false) end
        end
    end)
    
    tpBtn = Tab:CreateAction("Teleport to Player", "Player", function()
        if selectedTarget and selectedTarget ~= LocalPlayer.DisplayName then
            for _, p in pairs(Players:GetPlayers()) do
                if p.DisplayName == selectedTarget and p.Character then
                    local hrp = p.Character:FindFirstChild("HumanoidRootPart")
                    if hrp then Teleport(hrp.Position) end
                end
            end
        end
    end)

    Tab:CreateAction("Teleport to Plot", "Plot", function()
        local targetDisplay = selectedTarget or LocalPlayer.DisplayName
        local properties = workspace:FindFirstChild("Properties")
        if not properties then return end
        
        for _, plot in pairs(properties:GetChildren()) do
            local owner = plot:FindFirstChild("Owner")
            if owner and owner.Value then
                local ownerName = ""
                if typeof(owner.Value) == "Instance" and owner.Value:IsA("Player") then
                    ownerName = owner.Value.DisplayName
                elseif typeof(owner.Value) == "string" then
                    ownerName = owner.Value 
                end

                if ownerName == targetDisplay then
                    local origin = plot:FindFirstChild("OriginSquare")
                        or plot:FindFirstChild("Origin")
                        or plot:FindFirstChildOfClass("BasePart")
                    if origin then 
                        Teleport(origin.Position) 
                    end
                    break
                end
            end
        end
    end)

    tpBtn:SetDisabled(true)

    Tab:CreateSection("Coordinates")

    local function GetCurrentPosition()
        local Character = LocalPlayer.Character
        if not Character then return nil end

        local Humanoid = Character:FindFirstChildOfClass("Humanoid")
        local seatPart = Humanoid and Humanoid.SeatPart
        local vehicleModel = seatPart and seatPart:FindFirstAncestorOfClass("Model")

        if vehicleModel then
            return vehicleModel:GetPivot().Position
        elseif Character:FindFirstChild("HumanoidRootPart") then
            return Character.HumanoidRootPart.Position
        end
        return nil
    end

    local waypoints = {}
    local waypointCounter = 0
    local selectedWaypoint = nil

    local function GetWaypointNames()
        local list = {}
        for name in pairs(waypoints) do table.insert(list, name) end
        table.sort(list)
        return list
    end

    local waypointDropdown = Tab:CreateDropdown("Waypoints", GetWaypointNames(), "Select Waypoint...", function(val)
        selectedWaypoint = val
    end)

    Tab:CreateAction("Save Waypoint", "Save", function()
        local pos = GetCurrentPosition()
        if not pos then return end

        waypointCounter += 1
        local name = "Waypoint " .. waypointCounter
        waypoints[name] = pos
        selectedWaypoint = name
        waypointDropdown:SetOptions(GetWaypointNames())
    end)

    Tab:CreateAction("Teleport", "TP", function()
        if selectedWaypoint and waypoints[selectedWaypoint] then
            Teleport(waypoints[selectedWaypoint])
        end
    end)

    local function RefreshPlayerList()
        local list = GetPlayerList()
        playerDropdown:SetOptions(list)
        
        if selectedTarget then
            local stillPresent = false
            for _, name in ipairs(list) do
                if name == selectedTarget then stillPresent = true; break end
            end
            
            if not stillPresent then
                selectedTarget = nil
                tpBtn:SetDisabled(true)
            end
        end
    end

    Players.PlayerAdded:Connect(RefreshPlayerList)
    Players.PlayerRemoving:Connect(function()
        task.defer(RefreshPlayerList)
    end)
end

return TeleportModule